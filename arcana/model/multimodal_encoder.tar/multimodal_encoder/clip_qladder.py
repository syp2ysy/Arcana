from typing import Any, Optional, Tuple, Union
import torch
import torch.nn as nn
from transformers.models.clip.modeling_clip import CLIPVisionModel, CLIPMLP
from transformers.models.clip.configuration_clip import CLIPConfig
from transformers.utils import ModelOutput
from dataclasses import dataclass

class CLIPAttention(nn.Module):
    """Multi-headed attention from 'Attention Is All You Need' paper"""

    def __init__(self, config):
        super().__init__()
        self.config = config
        self.embed_dim = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.embed_dim // self.num_heads
        if self.head_dim * self.num_heads != self.embed_dim:
            raise ValueError(
                f"embed_dim must be divisible by num_heads (got `embed_dim`: {self.embed_dim} and `num_heads`:"
                f" {self.num_heads})."
            )
        self.scale = self.head_dim**-0.5
        self.dropout = config.attention_dropout

        self.k_proj = nn.Linear(self.embed_dim, self.embed_dim)
        self.v_proj = nn.Linear(self.embed_dim, self.embed_dim)
        self.q_proj = nn.Linear(self.embed_dim, self.embed_dim)
        self.out_proj = nn.Linear(self.embed_dim, self.embed_dim)

    def _shape(self, tensor: torch.Tensor, seq_len: int, bsz: int):
        return tensor.view(bsz, seq_len, self.num_heads, self.head_dim).transpose(1, 2).contiguous()

    def forward(
        self,
        q_hidden_states: torch.Tensor,
        kv_hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        causal_attention_mask: Optional[torch.Tensor] = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[Tuple[torch.Tensor]]]:
        """Input shape: Batch x Time x Channel"""

        bsz, tgt_len, embed_dim = q_hidden_states.size()

        # get query proj
        query_states = self.q_proj(q_hidden_states) * self.scale
        key_states = self._shape(self.k_proj(kv_hidden_states), -1, bsz)
        value_states = self._shape(self.v_proj(kv_hidden_states), -1, bsz)

        proj_shape = (bsz * self.num_heads, -1, self.head_dim)
        query_states = self._shape(query_states, tgt_len, bsz).view(*proj_shape)
        key_states = key_states.view(*proj_shape)
        value_states = value_states.view(*proj_shape)

        src_len = key_states.size(1)
        attn_weights = torch.bmm(query_states, key_states.transpose(1, 2))

        if attn_weights.size() != (bsz * self.num_heads, tgt_len, src_len):
            raise ValueError(
                f"Attention weights should be of size {(bsz * self.num_heads, tgt_len, src_len)}, but is"
                f" {attn_weights.size()}"
            )

        # apply the causal_attention_mask first
        if causal_attention_mask is not None:
            if causal_attention_mask.size() != (bsz, 1, tgt_len, src_len):
                raise ValueError(
                    f"Attention mask should be of size {(bsz, 1, tgt_len, src_len)}, but is"
                    f" {causal_attention_mask.size()}"
                )
            attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, src_len) + causal_attention_mask
            attn_weights = attn_weights.view(bsz * self.num_heads, tgt_len, src_len)

        if attention_mask is not None:
            if attention_mask.size() != (bsz, 1, tgt_len, src_len):
                raise ValueError(
                    f"Attention mask should be of size {(bsz, 1, tgt_len, src_len)}, but is {attention_mask.size()}"
                )
            attn_weights = attn_weights.view(bsz, self.num_heads, tgt_len, src_len) + attention_mask
            attn_weights = attn_weights.view(bsz * self.num_heads, tgt_len, src_len)

        attn_weights = nn.functional.softmax(attn_weights, dim=-1)

        if output_attentions:
            # this operation is a bit akward, but it's required to
            # make sure that attn_weights keeps its gradient.
            # In order to do so, attn_weights have to reshaped
            # twice and have to be reused in the following
            attn_weights_reshaped = attn_weights.view(bsz, self.num_heads, tgt_len, src_len)
            attn_weights = attn_weights_reshaped.view(bsz * self.num_heads, tgt_len, src_len)
        else:
            attn_weights_reshaped = None

        attn_probs = nn.functional.dropout(attn_weights, p=self.dropout, training=self.training)

        attn_output = torch.bmm(attn_probs, value_states)

        if attn_output.size() != (bsz * self.num_heads, tgt_len, self.head_dim):
            raise ValueError(
                f"`attn_output` should be of size {(bsz, self.num_heads, tgt_len, self.head_dim)}, but is"
                f" {attn_output.size()}"
            )

        attn_output = attn_output.view(bsz, self.num_heads, tgt_len, self.head_dim)
        attn_output = attn_output.transpose(1, 2)
        attn_output = attn_output.reshape(bsz, tgt_len, embed_dim)

        attn_output = self.out_proj(attn_output)

        return attn_output, attn_weights_reshaped

@dataclass
class LadderModelOutputWithPooling(ModelOutput):
    """
    Base class for model's outputs that also contains a pooling of the last hidden states.

    Args:
        last_hidden_state (`torch.FloatTensor` of shape `(batch_size, sequence_length, hidden_size)`):
            Sequence of hidden-states at the output of the last layer of the model.
        pooler_output (`torch.FloatTensor` of shape `(batch_size, hidden_size)`):
            Last layer hidden-state of the first token of the sequence (classification token) after further processing
            through the layers used for the auxiliary pretraining task. E.g. for BERT-family of models, this returns
            the classification token after processing through a linear layer and a tanh activation function. The linear
            layer weights are trained from the next sentence prediction (classification) objective during pretraining.
        hidden_states (`tuple(torch.FloatTensor)`, *optional*, returned when `output_hidden_states=True` is passed or when `config.output_hidden_states=True`):
            Tuple of `torch.FloatTensor` (one for the output of the embeddings, if the model has an embedding layer, +
            one for the output of each layer) of shape `(batch_size, sequence_length, hidden_size)`.

            Hidden-states of the model at the output of each layer plus the optional initial embedding outputs.
        attentions (`tuple(torch.FloatTensor)`, *optional*, returned when `output_attentions=True` is passed or when `config.output_attentions=True`):
            Tuple of `torch.FloatTensor` (one for each layer) of shape `(batch_size, num_heads, sequence_length,
            sequence_length)`.

            Attentions weights after the attention softmax, used to compute the weighted average in the self-attention
            heads.
    """

    last_hidden_state: torch.FloatTensor = None
    pooler_output: torch.FloatTensor = None
    hidden_states: Optional[Tuple[torch.FloatTensor, ...]] = None
    ladder_hidden_states: Optional[Tuple[torch.FloatTensor, ...]] = None
    attentions: Optional[Tuple[torch.FloatTensor, ...]] = None


class LadderCLIPEncoderLayer(nn.Module):
    def __init__(self, config: CLIPConfig):
        super().__init__()
        # import pdb;pdb.set_trace()
        self.embed_dim = config.hidden_size
        self.layer_norm0 = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)
        self.cross_attn = CLIPAttention(config)
        self.layer_norm1 = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)
        self.mlp = CLIPMLP(config)
        self.layer_norm2 = nn.LayerNorm(self.embed_dim, eps=config.layer_norm_eps)

        

    def forward(
        self,
        query_hidden_states: torch.Tensor,
        main_hidden_states: torch.Tensor,
        attention_mask: torch.Tensor = None,
        causal_attention_mask: torch.Tensor = None,
        output_attentions: Optional[bool] = False,
    ) -> Tuple[torch.FloatTensor]:
        """
        Args:
            hidden_states (`torch.FloatTensor`): input to the layer of shape `(batch, seq_len, embed_dim)`
            attention_mask (`torch.FloatTensor`): attention mask of size
                `(batch, 1, tgt_len, src_len)` where padding elements are indicated by very large negative values.
                `(config.encoder_attention_heads,)`.
            output_attentions (`bool`, *optional*):
                Whether or not to return the attentions tensors of all attention layers. See `attentions` under
                returned tensors for more detail.
        """
        
        # hidden_states = self.fc_merge(torch.cat([main_hidden_states, ladder_hidden_states], dim=-1))
        q_hidden_states = query_hidden_states
        kv_hidden_states = main_hidden_states

        residual = q_hidden_states
        
        residual = q_hidden_states
        q_hidden_states = self.layer_norm0(q_hidden_states)
        kv_hidden_states = self.layer_norm1(kv_hidden_states)
        hidden_states, attn_weights = self.cross_attn(
            q_hidden_states=q_hidden_states,
            kv_hidden_states=kv_hidden_states,
            attention_mask=attention_mask,
            causal_attention_mask=causal_attention_mask,
            output_attentions=output_attentions,
        )
        hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.layer_norm2(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (attn_weights,)

        return outputs

class CLIPWithLadderAdapter(CLIPVisionModel):
    def __init__(self, config):
        super(CLIPWithLadderAdapter, self).__init__(config)
        # Add the ladder adapters to each layer
        self.LadderAdapters = nn.ModuleList([LadderCLIPEncoderLayer(config) for _ in range(config.num_hidden_layers)])
        # Add the Query embedding
        self.qladder_embeds = nn.Parameter(torch.randn((1, 64, config.hidden_size)))
        self.post_init()

    def forward(self, pixel_values, return_dict=True, output_attentions=False, output_hidden_states=True):
        outputs = super(CLIPWithLadderAdapter, self).forward(pixel_values, return_dict=return_dict, output_attentions=output_attentions, output_hidden_states=output_hidden_states)
        
        # >> q_ladder
        for idx, adapter in enumerate(self.LadderAdapters):
            if idx == 0:
                # print(self.qladder_embeds)
                # print(self.LadderAdapters[0].mlp.fc1.weight)
                q_embeds = self.qladder_embeds
                q_embeds = q_embeds.repeat(outputs.hidden_states[idx].shape[0], 1, 1)
            kv_embeds = outputs.hidden_states[idx]
            q_embeds = adapter(q_embeds, kv_embeds)[0]

        return LadderModelOutputWithPooling(
            last_hidden_state=outputs.last_hidden_state,
            pooler_output=outputs.pooler_output,
            hidden_states=outputs.hidden_states,
            ladder_hidden_states=q_embeds,
        )

# def build_ladder(config_path):
#     # Add the ladder adapters to each layer
#     from transformers import AutoConfig
#     # import pdb; pdb.set_trace()
#     config = AutoConfig.from_pretrained(config_path)
    
#     LadderAdapters = nn.ModuleList([LadderCLIPEncoderLayer(config.vision_config) for _ in range(config.vision_config.num_hidden_layers)])
#     return LadderAdapters

# def forward_ladder(outputs, LadderAdapters):
#     # print(outputs.keys())
#     ladder_states=()
#     for idx, adapter in enumerate(LadderAdapters):
#         if idx == 0:
#             last_hidden_states = outputs.hidden_states[0]

#         kv_hidden_states = outputs.hidden_states[idx+6]
#         # import pdb;pdb.set_trace()
#         last_hidden_states = adapter(last_hidden_states, kv_hidden_states)[0]
#         ladder_states = ladder_states + (last_hidden_states,)
            
#     # Update the outputs with the modified last_hidden_states
#     outputs.last_hidden_state=last_hidden_states
#     # import pdb;pdb.set_trace()
#     return LadderModelOutputWithPooling(
#         last_hidden_state=outputs.last_hidden_state,
#         pooler_output=outputs.pooler_output,
#         hidden_states=outputs.hidden_states,
#         ladder_hidden_states=ladder_states,
#     )

# model = CLIPWithLadderAdapter.from_pretrained("/root/paddlejob/workspace/env_run/LLaVA/pretrain_weight/clip-vit-large-patch14-336")
# import pdb; pdb.set_trace()
# layers_weight = model.vision_model.encoder.layers.state_dict()
# keys_to_delete = []
# items_list = list(layers_weight.items())
# for key, value in items_list:
#     if 'self_attn' in key:
#         corss_key = key.replace('self_attn', 'cross_attn')
#         layers_weight[corss_key] = value
#         keys_to_delete.append(key)
# import pdb; pdb.set_trace()
# for key in keys_to_delete:
#     del layers_weight[key]
# import pdb; pdb.set_trace()
# print(model.config)